<!DOCTYPE html>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="style221.css" />
	<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,200,300,600,700' rel='stylesheet' type='text/css'>
	<title>RPSRview</title>
	<meta charset="UTF-8" />
</head>
<body>
	<div class="header">
		<h1><a href="https://cormacbrady.info/~tkek"><strong>RPSR</strong>view</a></h1>
		<p>database of reserves</p>
		<a class="gitlogo" href="https://github.com/cob16/cs-221-group-project"> <img src="https://assets-cdn.github.com/images/modules/logos_page/GitHub-Mark.png" height="45" width="45"></a>
	</div>

	<div class="container">

		<?php
		$user = 'tkek';
		$pass = 'topkek3';
		$database = 'cb-group-project';
		mysql_connect(localhost,$username,$password);
		@mysql_select_db($database) or die( "Unable to select database");
		$query="SELECT * FROM Recordings";
		$result=mysql_query($query);
		$num=mysql_numrows($result);mysql_close();?>
		
		<table border="0" cellspacing="2" cellpadding="2">
	

	<tr>
	<td>
	<font face="Arial, Helvetica, sans-serif">Reserve Name</font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif">Species</font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif">DAFOR</font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif">Comment</font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif">Date Recorded</font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif">User</font>
	</td>
	</tr>
	<?php $i=0;
	while ($i < $num) {$f1=mysql_result($result,$i,"field1");
	$f2=mysql_result($result,$i,"field2");$f3=mysql_result($result,$i,"field3");
	$f4=mysql_result($result,$i,"field4");$f5=mysql_result($result,$i,"field5");?>
	<tr>
	<td>
	<font face="Arial, Helvetica, sans-serif"><?php echo $f1; ?></font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif"><?php echo $f2; ?></font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif"><?php echo $f3; ?></font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif"><?php echo $f4; ?></font>
	</td>
	<td>
	<font face="Arial, Helvetica, sans-serif"><?php echo $f5; ?></font>
	</td>
	</tr>

	<?php$i++;}?>
</body>
</html>



