<?php include 'header.html';/* this adds the header.html file
to the beginning of the file, do not remove */
include 'connect.php';
?>


<div class="container">
<form action="update_record.php" method="post">

<?php

if(!$conn->connect_errno > 0){ //if connection was successful

    $res = "SELECT * FROM Reserves";

    if(!$res = $conn->query($res)){
        die('There was an error running the query [' . $db->error . ']');
    }
    echo '<p><input type="submit" name ="deleteitems" class="btn btn-danger" id="" value ="Delete Selected" /></p>';
    echo '<p><a href="index.php" class="btn btn-primary">Cancel</a></p>';
    //echo '<div id="content">';
    //echo '<table cellpadding="25">';
    echo '<table>';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Reserve Name</th>';
    echo '<th>Location</th>';
    echo '<th>Description</th>';
    echo '</tr>';
    echo '</thead>';
    while ($a = $res->fetch_assoc()) {
        $name = substr($a['reserve_name'],0,39);
        $description = substr($a['description'],0,39);
        $desclength = strlen($a['description']);
        $namelength = strlen($a['reserve_name']);
        echo '<tr>';
        if($namelength>40){
            echo '<td>'.$name.'...</td>';
        }
        else{
            echo '<td>'.$name.'</td>';
        }

        if($a['grid_reference']==0){
            echo '<td><em>No location provided</em></td>';
        }
        else{
            echo '<td>'.$a["grid_reference"].'</td>';
        }
        if($desclength>40){
            echo '<td>'.$description.'...</td>';
        }
        else{
            if($desclength==0){
                echo '<td><em>No description provided</em></td>';
            }
            else{
                echo '<td>'.$a["description"].'</td>';
            }

        }
        echo '<td>Delete?<input type="checkbox" name="deletelist[]" value="'.$a["reserve_ID"].'"></td>';
        echo '<td><button type="submit" name="update" class="btn btn-default" value="'.$a["reserve_ID"].'">Update</button></td>';
        echo '</tr>';
    }
    echo '</table>';
    //echo '</div>';

  }
?>

    </form>
    </div>
  </body>
</html>
