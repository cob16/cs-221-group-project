<?php include 'header.html';/* this adds the header.html file
to the beginning of the file, do not remove */
include 'connect.php';


//ADD NEW RESERVE
if (isset($_POST['add_reserve']))
{
    $new_record = $_POST['reserve_name'];
    $new_reference = $_POST['grid_reference'];
    $new_description = $_POST['description'];

    if(!$conn->connect_errno > 0){
        $add = 'INSERT INTO Reserves (reserve_name, grid_reference, description) VALUES ("' . $new_record . '", "' . $new_reference . '", "' . $new_description . '")';
        if(!$add = $conn->query($add)){
            die('There was an error running the query [' . $db->error . ']');
        }
    }

    header('Location: index.php');
    exit;
}
?>


<script>

    function check_input(){
        var gridRegExp = /[a-zA-Z0-9]{8}/;
        var textRegExp = /[a-zA-Z 0-9]/;

        if(textRegExp.test(document.details.reserve_name.value)
            && gridRegExp.test(document.details.grid_reference.value)
            && textRegExp.test(document.details.description.value))
        {
            document.details.setAttribute("method", "post");
            document.details.setAttribute("action", "add_reserve.php");
        }
        else if(!textRegExp.test(document.details.reserve_name.value)){
            alert("Invalid Reserve Name details entered");
        }
        else if(!gridRegExp.test(document.details.grid_reference.value)){
            alert("Invalid grid reference entered, use a 6 figure OS grid reference" +
            " (ie, two letters then 6 numbers");
        }
        else if(!textRegExp.test(document.details.description.value)){
            alert("Invalid description entered");
        }

    }

</script>

<div class="container">

    <form name="details" onsubmit="check_input()">
    <!--<form name="details" action="add_the_reserve.php" method="post">-->
    <table cellpadding="25">
    <thead>
    <tr>
    <th>Add New Reserve:</th>
    </tr>
    <table cellpadding="25">
    </thead>
        <tr><td><input type="text" name="reserve_name" placeholder="Reserve Name" /></td></tr>
        <tr><td><input type="text" name="grid_reference" placeholder="OS Grid Reference" /></td></tr>
        <tr><td><input type="text" name="description" placeholder="Reserve Description" /></td></tr>
        <tr><td><input type="submit" name="add_reserve" class="btn btn-success" value="Add Reserve" /></td></tr>
    </table>
    </form>


</div>
</body>
</html>
