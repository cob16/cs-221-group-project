<!-- HIGHLY EXPERIMENTAL CODE THAT WILL PROBABLY BE SHIT AND SO THEREFORE WILL BE SCRAPPED BUT  IM STILL GONNA TRY AND DO IT ANYWAY FOR THE GREATER GOOD -->
<div class="row">

    <?php


    if(!$conn->connect_errno > 0){ //if connection was successful
        $res = 'SELECT * FROM Reserves ORDER BY reserve_name';
        if(!$res = $conn->query($res)){
            die('There was an error running the query [' . $db->error . ']');
        }

        while ($a = $res->fetch_assoc()) {
            $name = substr($a['reserve_name'],0,29);
            $description = substr($a['description'],0,29);
            $desclength = strlen($a['description']);
            $namelength = strlen($a['reserve_name']);

            $resid = $a["reserve_ID"];
            $pic = 'SELECT * FROM Recordings WHERE reserve_name = "' . $resid . '" LIMIT 1';


            


            if(!$pic = $conn->query($pic)){
                die('There was an error running the query hola atch boi');
            }

            echo '<div class="col-md-4">';
            echo '<div class="thumbnail">';

           
            if (isset($hola["photo_path_general"])) {


            echo '<img src="' . $hola["photo_path_general"] . '" width="243px" height="200px">';
        }
        else {
            echo '<p>hello</p>';
        }

         if($namelength>30){
                echo '<h3><a href="records.php?reserve=' . $a["reserve_ID"] . '">' . ucwords($name) .'...</a></h3>';
            }
            else{
                echo '<h3><a href="records.php?reserve=' . $a["reserve_ID"] . '">' . ucwords($name) .'</a></h3>';
            }


            echo '<p> Location: ' . $a['grid_reference'] . '</p>';
            $hola = $pic->fetch_assoc();
            echo '<div class="caption">';


            if($desclength>30){
                echo '<p>' . $description . '...</p>';
            }
            else{
                echo '<p>' . $description . '</p>';
            }

            echo '<p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p>';
            echo '</div>';
            echo '</div>';
            echo '</div>';



        }
    }


    ?>
