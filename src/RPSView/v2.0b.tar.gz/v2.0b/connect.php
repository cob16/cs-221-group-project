<?php
		$host = 'localhost';
		$user = 'tkek';
		$pass = 'topkek3';
		$database = 'cb-group-project';
		$conn = new mysqli($host, $user, $pass, $database);
		?>