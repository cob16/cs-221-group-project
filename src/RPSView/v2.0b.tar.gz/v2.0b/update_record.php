<?php include 'header.html';/* this adds the header.html file
to the beginning of the file, do not remove */
include 'connect.php';
?>

<?php
//DELETE SELECTED ITEMS
if (isset($_POST['deleteitems']))
{
    $delete_list = $_POST['deletelist'];
    foreach($delete_list as $value){
        if(!$conn->connect_errno > 0){
            $res = 'DELETE FROM Reserves WHERE reserve_ID="'.$value.'"';
            if(!$res = $conn->query($res)){
                die('There was an error running the query [' . $db->error . ']');
            }
        }
    }
    header('Location: edit_list.php');
    exit;
}

//UPDATE EDITED ITEM
if (isset($_POST['update_reserve']))
{
    $update_name = $_POST['updatename'];
    $update_id = $_POST['update_reserve'];
    $update_grid = $_POST['updategrid'];
    $update_desc = $_POST['updatedesc'];

    if(!$conn->connect_errno > 0){
        $res = 'UPDATE Reserves SET reserve_name="'.$update_name .'", grid_reference="'.$update_grid.'", description="'.$update_desc.'" WHERE reserve_ID="'.$update_id.'"';
        if(!$res = $conn->query($res)){
            die('There was an error running the query [' . $db->error . ']');
        }
    }

    header('Location: edit_list.php');
    exit;
}

?>


<script>

    function check_input(){
        var gridRegExp = /[a-zA-Z0-9]{8}/;
        var textRegExp = /[a-zA-Z 0-9]/;

        if(textRegExp.test(document.details.updatename.value)
            && gridRegExp.test(document.details.updategrid.value)
            && textRegExp.test(document.details.updatedesc.value))
        {
            document.details.setAttribute("method", "post");
            document.details.setAttribute("action", "update_record.php");
        }
        else if(!textRegExp.test(document.details.updatename.value)){
            alert("Invalid Reserve Name details entered");
        }
        else if(!gridRegExp.test(document.details.updategrid.value)){
            alert("Invalid grid reference entered, use a 6 figure OS grid reference" +
            " (ie, two letters then 6 numbers");
        }
        else if(!textRegExp.test(document.details.updatedesc.value)){
            alert("Invalid description entered");
        }

    }

</script>

<div class="container">

    <form name="details" onsubmit="check_input()">
        <!--<form name="details" action="add_the_reserve.php" method="post">-->
        <?php
        $reserve_id = $_POST['update'];

        if(!$conn->connect_errno > 0) { //if connection was successful
            $res = "SELECT * FROM Reserves WHERE reserve_ID='" . $reserve_id . "'";


            if (!$res = $conn->query($res)) {
                die('There was an error running the query [' . $db->error . ']');
            }
            while ($a = $res->fetch_assoc()) {
                $reserve_name = $a['reserve_name'];
                $reserve_ref = $a['grid_reference'];
                $reserve_desc = $a['description'];

                echo '<table cellpadding="25">';
                echo '<thead>';
                echo '<tr>';
                echo ' <th>Update Reserve:</th>';
                echo '</tr>';
                echo '<table cellpadding="25">';
                echo '</thead>';
                echo '<td><input type="text" name="updatename" value="' . $a["reserve_name"] . '" /></td>';
                echo '<td><input type="text" name="updategrid" value="' . $a["grid_reference"] . '" /></td>';
                echo '<td><input type="text" name="updatedesc" value="' . $a["description"] . '" /></td>';
                //echo '<tr><td><input type="submit" name="update_reserve" value="Update Reserve" /></td></tr>';
                echo '<td><button type="submit" name="update_reserve" class="btn btn-success" value="'.$a["reserve_ID"].'">Update Reserve</button></td>';
                echo '</table>';

            }
        }
        ?>
    </form>


</div>
</body>
</html>