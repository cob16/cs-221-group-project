<!DOCTYPE html>
<html lang="en">

<head>
    <title>RPSRview</title>
    <meta charset="utf-8">
    <link rel="shortcut icon" type="image/png" href="favicon.ico"/>

   <!--  <link rel="stylesheet" type="text/css" href="style221.css" />
	<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,200,300,600,700' rel='stylesheet' type='text/css'>
	<meta charset="UTF-8" />
 -->
    <!-- These files are needed so that I can use "Twitter Bootstrap" -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>    
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="js/bootstrap.min.js" rel="stylesheet">

    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

</head>

<body>

<!-- This is the navigation bar that appears at the top of every page -->
    <nav class="navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">            
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/~tkek/">RPSRview</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
               <ul class="nav navbar-nav navbar-right">
                <li>
               <a class="brand" href="https://github.com/cob16/cs-221-group-project"><i class="fa fa-github fa-4x" style="color:white"></i></a>
               </li>
               </ul>
            </div>

        </div>

    </nav>  


    









<!-- <div class="header">
		<h1><a href="https://cob16.github.io/cs-221-group-project"><strong>RPSR</strong>view</a></h1>
		<p>database of reserves</p>
		<a class="gitlogo" href="https://github.com/cob16/cs-221-group-project"> <img src="https://assets-cdn.github.com/images/modules/logos_page/GitHub-Mark.png" height="45" width="45"></a>
	</div>
  
 -->
   
